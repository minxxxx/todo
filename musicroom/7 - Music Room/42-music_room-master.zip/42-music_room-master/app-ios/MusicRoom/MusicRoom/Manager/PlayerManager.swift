//
//  PlayerManager.swift
//  MusicRoom
//
//  Created by jdavin on 11/8/18.
//  Copyright © 2018 Etienne Tranchier. All rights reserved.
//

import UIKit

class PlayerManager: NSObject, DZRPlayerDelegate {
    
}
