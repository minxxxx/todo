//
// Created by GFaure on 19/06/2014.
// Copyright (c) 2014 Deezer. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol DZRCancelable <NSObject>
- (void)cancel;
@end
