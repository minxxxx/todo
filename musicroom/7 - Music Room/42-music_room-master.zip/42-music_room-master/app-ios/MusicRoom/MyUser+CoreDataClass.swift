//
//  MyUser+CoreDataClass.swift
//  
//
//  Created by Etienne TRANCHIER on 11/14/18.
//
//

import Foundation
import CoreData


public class MyUser: NSManagedObject {

}
